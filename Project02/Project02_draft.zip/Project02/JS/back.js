window.onload(function(){

    setTimeout(function(){
       window.location = "two.html"
   	 7000);}

});