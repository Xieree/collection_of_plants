$(window).load(function(){

	setTimeout(function(){
		window.location.href = 'two.html';
	 }, 4000);
});
